const fs = require('fs');
const path = require('path');
const { PermissionFlagsBits } = require('discord.js');

const SUPPORT_EMOJI_LIMITS = { 0: 50, 1: 100, 2: 150, 3: 250 };
const SUPPORT_STICKER_LIMITS = { 0: 5, 1: 15, 2: 30, 3: 60 };

function formatDiscordError(err) {
  return [
    err?.message,
    err?.code != null ? `code=${err.code}` : null,
    err?.status != null ? `status=${err.status}` : null
  ].filter(Boolean).join(' | ');
}

const ASSET_DIR = path.join(__dirname, '../../assets');
const EMOJI_DIR = path.join(ASSET_DIR, 'emojis');
const STICKER_DIR = path.join(ASSET_DIR, 'stickers');

// Every visual symbol used by VERDO should resolve to one of these application emojis.
// The names are intentionally stable so the IDs can be cached in memory and recreated
// automatically if an application emoji is deleted from the Developer Portal.
const EMOJI_FILES = {
  mascot_1: 'mascot_1.png', mascot_2: 'mascot_2.png', mascot_3: 'mascot_3.png', mascot_4: 'mascot_4.png',
  mascot_5: 'mascot_5.png', mascot_6: 'mascot_6.png', mascot_7: 'mascot_7.png', mascot_8: 'mascot_8.png',
  v: 'v.png', verdo: 'verdo.png', vgear: 'vgear.png', gears: 'gears.png', gear: 'gear.png',
  vcircle: 'vcircle.png', vhex: 'vhex.png', flag: 'flag.png', yes: 'yes.png', no: 'no.png',
  info: 'info.png', warn: 'warn.png', question: 'question.png', lock: 'lock.png', server: 'server.png',
  crown: 'crown.png', bolt: 'bolt.png', spark: 'spark.png', discord: 'discord.png', users: 'users.png',
  adduser: 'adduser.png', shield: 'shield.png', ticket: 'ticket.png', game: 'game.png', stats: 'stats.png',
  settings: 'settings.png', chat: 'chat.png', link: 'link.png', like: 'like.png', dislike: 'dislike.png',
  fire: 'fire.png', star: 'star.png', heart: 'heart.png', broken: 'broken.png', sleep: 'sleep.png',
  crown2: 'crown2.png', party: 'party.png', gift: 'gift.png',
  // Extended branded aliases: these are separate Application Emojis so the bot
  // can customize the additional symbols used throughout commands, logs and UI.
  voice: 'chat.png', online: 'yes.png', offline: 'no.png', alert: 'warn.png', danger: 'no.png',
  timer: 'stats.png', clock: 'stats.png', broom: 'settings.png', door: 'link.png', stop: 'no.png',
  shop: 'gift.png', cart: 'gift.png', human: 'adduser.png', puzzle: 'settings.png', calculator: 'stats.png',
  coin: 'verdo.png', eye: 'info.png', pray: 'heart.png', sad: 'broken.png', mute: 'sleep.png',
  speaker: 'chat.png', search: 'info.png', bell: 'chat.png', pin: 'ticket.png', paperclip: 'link.png',
  medal_gold: 'crown2.png', medal_silver: 'crown2.png', medal_bronze: 'crown2.png',
  mic: 'chat.png', microphone: 'chat.png', cleanup: 'settings.png', alert_red: 'warn.png',
  money: 'verdo.png', gem: 'vcircle.png', globe: 'link.png', world: 'server.png',
  recycle: 'link.png', edit: 'settings.png', trash: 'no.png', folder: 'server.png'
};

// Also discover every image physically present in assets/emojis. This guarantees
// that newly created VERDO emoji PNGs are uploaded automatically without having
// to remember to add another entry to EMOJI_FILES. Explicit entries keep their
// stable aliases/names; discovered files use their filename stem as the Discord name.
const DISCOVERED_EMOJI_FILES = fs.existsSync(EMOJI_DIR)
  ? Object.fromEntries(
      fs.readdirSync(EMOJI_DIR)
        .filter(f => /\.(png|apng|webp)$/i.test(f))
        .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }))
        .map(f => [path.parse(f).name, f])
    )
  : {};
const ALL_EMOJI_FILES = { ...DISCOVERED_EMOJI_FILES, ...EMOJI_FILES };

// Sticker tags must be the Discord *name* of a unicode emoji (e.g. "robot"), not the emoji character.
// sticker_1..sticker_10 are ordered by priority: a level-0 support server only has 5 sticker slots,
// so the first five are the ones that get published.
const STICKER_META = {
  sticker_1:  { tags: 'robot',       description: 'VERDO holding the VERDO sign' },
  sticker_2:  { tags: 'video_game',  description: 'VERDO says GG' },
  sticker_3:  { tags: 'heart',       description: 'VERDO hugging a heart' },
  sticker_4:  { tags: 'sunglasses',  description: 'VERDO wearing cool shades' },
  sticker_5:  { tags: 'heart_eyes',  description: 'VERDO with heart eyes' },
  sticker_6:  { tags: 'crown',       description: 'VERDO wearing a crown' },
  sticker_7:  { tags: 'sparkles',    description: 'Happy VERDO with sparkles' },
  sticker_8:  { tags: 'question',    description: 'Confused VERDO' },
  sticker_9:  { tags: 'sweat_drop',  description: 'Nervous VERDO' },
  sticker_10: { tags: 'rage',        description: 'Angry VERDO' }
};

const STICKER_FILES = Object.fromEntries(
  fs.existsSync(STICKER_DIR)
    ? fs.readdirSync(STICKER_DIR)
        .filter(f => /\.(png|apng|webp)$/i.test(f))
        // numeric order (sticker_2 before sticker_10) so priority order is respected
        .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }))
        .map(f => [path.parse(f).name, f])
    : []
);

const UNICODE_TO_NAME = new Map([
  ['😀','mascot_1'],['😄','mascot_1'],['😊','mascot_1'],['🙂','mascot_1'],['😉','mascot_2'],['😏','mascot_2'],
  ['🥰','mascot_3'],['😍','mascot_3'],['😎','mascot_4'],['🤬','mascot_5'],['😡','mascot_5'],['😇','mascot_6'],
  ['👑','crown'],['🤖','mascot_3'],['⚙️','gear'],['⚙','gear'],['🔧','settings'],['✅','yes'],['❌','no'],
  ['⚠️','warn'],['⚠','warn'],['❓','question'],['❔','question'],['🔒','lock'],['🔐','lock'],['💬','chat'],
  ['📊','stats'],['🎫','ticket'],['🛡️','shield'],['🛡','shield'],['💰','verdo'],['💵','verdo'],['🎁','gift'],
  ['❤️','heart'],['❤','heart'],['💔','broken'],['🔥','fire'],['⭐','star'],['🌟','star'],['🎉','party'],
  ['🎊','party'],['⚡','bolt'],['✨','spark'],['🔗','link'],['👥','users'],['👤','adduser'],['🎮','game'],
  ['💤','sleep'],['😴','sleep'],['👍','like'],['👎','dislike'],['🖥️','server'],['🖥','server'],['📋','server'],
  ['📌','ticket'],['🚀','bolt'],['💎','vcircle'],['🔵','vcircle'],['🔷','vhex'],['🏆','crown2'],['🏅','crown2'],
  ['♻','link'],['⚪','vcircle'],['⛔','no'],['✏','settings'],['➕','adduser'],['➖','dislike'],['🆕','spark'],
  ['🌍','server'],['🌐','link'],['🍀','verdo'],['🎖','crown2'],['🎙','chat'],['🎨','spark'],['🎭','mascot_5'],
  ['🏦','server'],['🏧','server'],['🐌','sleep'],['👁','info'],['👇','adduser'],['👋','mascot_1'],['👢','dislike'],
  ['💀','no'],['💡','spark'],['💳','verdo'],['💼','server'],['📁','server'],['📄','info'],['📅','server'],['📆','server'],
  ['📈','stats'],['📉','stats'],['📎','link'],['📜','info'],['📝','info'],['📢','chat'],['📨','chat'],['📩','chat'],
  ['📭','chat'],['🔁','link'],['🔄','link'],['🔇','sleep'],['🔊','chat'],['🔎','info'],['🔐','lock'],['🔓','lock'],
  ['🔔','chat'],['🔘','vcircle'],['🔨','settings'],['🔴','no'],['🗂','server'],['🗄','server'],['🗑','no'],['🗓','server'],
  ['😈','mascot_5'],['🎙️','chat'],['🎖️','crown2'],
  ['⏰','timer'],['⏱️','timer'],['⏱','timer'],['⏳','timer'],['♻','recycle'],['⚙','gear'],['⚙️','gear'],
  ['⚠','warn'],['⚠️','warn'],['⚡','bolt'],['⚪','vcircle'],['⛔','no'],['✏','edit'],['✨','spark'],['❌','no'],
  ['❓','question'],['❔','question'],['❤','heart'],['❤️','heart'],['➕','adduser'],['➖','dislike'],['🆕','spark'],
  ['🌍','world'],['🌐','globe'],['🌟','star'],['🍀','verdo'],['🎁','gift'],['🎉','party'],['🎊','party'],['🎖','medal_gold'],
  ['🎙','mic'],['🎨','spark'],['🎫','ticket'],['🎭','mascot_5'],['🎮','game'],['🏅','medal_gold'],['🏆','crown2'],
  ['🏦','server'],['🏧','server'],['🐌','sleep'],['👁','eye'],['👇','adduser'],['👋','mascot_1'],['👢','dislike'],
  ['💀','no'],['💎','gem'],['💡','spark'],['💤','sleep'],['💬','chat'],['💰','money'],['💳','money'],['💵','money'],['💼','server'],
  ['📁','folder'],['📄','info'],['📅','timer'],['📆','timer'],['📈','stats'],['📉','stats'],['📊','stats'],['📋','server'],
  ['📌','pin'],['📎','paperclip'],['📜','info'],['📝','info'],['📢','speaker'],['📨','chat'],['📩','chat'],['📭','chat'],
  ['🔁','recycle'],['🔄','recycle'],['🔇','mute'],['🔊','speaker'],['🔎','search'],['🔐','lock'],['🔒','lock'],['🔓','lock'],
  ['🔔','bell'],['🔗','link'],['🔘','vcircle'],['🔧','settings'],['🔨','settings'],['🔴','no'],['🔵','vcircle'],['🔷','vhex'],
  ['🖥','server'],['🖥️','server'],['🗂','folder'],['🗄','server'],['🗑','trash'],['🗓','timer'],['😀','mascot_1'],['😄','mascot_1'],
  ['😇','mascot_6'],['😈','mascot_5'],['😉','mascot_2'],['😊','mascot_1'],['😍','mascot_3'],['😎','mascot_4'],['😏','mascot_2'],
  ['😡','mascot_5'],['😢','sad'],['😴','sleep'],['🙂','mascot_1'],['🙈','sleep'],['🙏','pray'],['🚀','bolt'],['🚨','alert_red'],
  ['🚪','door'],['🚫','danger'],['🛍','shop'],['🛒','cart'],['🛡','shield'],['🛡️','shield'],['🟢','online'],['🤖','mascot_3'],
  ['🤬','mascot_5'],['🥇','medal_gold'],['🥈','medal_silver'],['🥉','medal_bronze'],['🥰','mascot_3'],['🧑','human'],['🧩','puzzle'],
  ['🧮','calculator'],['🧹','broom'],['🪙','coin'],['👍','like'],['👎','dislike'],['👑','crown']
]);

let applicationEmojiCache = new Map();
let supportEmojiCache = new Map();
let supportStickerCache = new Map();

function tagFromEmoji(emoji) {
  if (!emoji) return null;
  return emoji.toString();
}

function getVerdoEmoji(name) {
  const e = applicationEmojiCache.get(name);
  return e ? tagFromEmoji(e) : null;
}

function resolveCustomEmoji(value) {
  if (typeof value !== 'string') return null;
  const exact = getVerdoEmoji(value);
  if (exact) return exact;
  const name = UNICODE_TO_NAME.get(value);
  return name ? getVerdoEmoji(name) : null;
}

function replaceVerdoEmojiText(value) {
  if (typeof value !== 'string') return value;
  let out = value;
  // Longest first prevents the variation-selector form from being partially replaced.
  [...UNICODE_TO_NAME.keys()].sort((a,b) => b.length-a.length).forEach(unicode => {
    const custom = resolveCustomEmoji(unicode);
    if (custom) out = out.split(unicode).join(custom);
  });
  // Final safety net: any emoji not explicitly listed above is still replaced
  // by the branded VERDO emoji instead of leaving a native Unicode emoji behind.
  const generic = getVerdoEmoji('verdo');
  if (generic) {
    try {
    } catch (_) {}
    try {
      out = out.replace(/\p{Extended_Pictographic}(?:\uFE0F|[\u{1F3FB}-\u{1F3FF}])?(?:\u200D\p{Extended_Pictographic}(?:\uFE0F|[\u{1F3FB}-\u{1F3FF}])?)*/gu, m => {
        return UNICODE_TO_NAME.has(m) ? m : generic;
      });
    } catch (_) {}
  }
  return out;
}

function transformPayload(value, key = '') {
  if (typeof value === 'string') {
    // Never rewrite IDs, URLs, file paths, custom IDs, or asset names.
    // Emoji fields are handled below so component/button emojis become real
    // Discord custom emoji objects instead of remaining Unicode.
    if (/id$|url$|^custom_id$|^name$|path|file/i.test(key)) return value;
    // Discord component emojis must be API emoji objects, not raw Unicode strings.
    // Convert known Unicode emojis to the matching VERDO custom emoji when possible.
    if (key === 'emoji') {
      const emojiName = UNICODE_TO_NAME.get(value);
      const custom = emojiName ? applicationEmojiCache.get(emojiName) : null;
      if (custom) return { id: custom.id, name: custom.name };
    }
    return replaceVerdoEmojiText(value);
  }
  if (key === 'emoji' && value && typeof value === 'object' && !Array.isArray(value)) {
    const unicodeName = typeof value.name === 'string' ? UNICODE_TO_NAME.get(value.name) : null;
    const custom = unicodeName ? applicationEmojiCache.get(unicodeName) : null;
    if (custom) return { id: custom.id, name: custom.name };
    if (typeof value.name === 'string' && /\p{Extended_Pictographic}/u.test(value.name)) {
      const fallback = applicationEmojiCache.get('verdo');
      if (fallback) return { id: fallback.id, name: fallback.name };
    }
    return value;
  }
  if (Array.isArray(value)) return value.map(v => transformPayload(v, key));
  if (!value || typeof value !== 'object') return value;
  if (Buffer.isBuffer(value)) return value;

  // discord.js builders expose their mutable payload through `.data`.
  if (value.data && typeof value.data === 'object') transformPayload(value.data, key);

  for (const [k, v] of Object.entries(value)) {
    if (k === 'data' || k === 'client' || k === 'guild' || k === 'channel' || k === 'user') continue;
    const next = transformPayload(v, k);
    if (typeof next === 'string' || Array.isArray(next)) value[k] = next;
  }
  return value;
}

function patchSendMethods(discord) {
  const classes = [discord.BaseInteraction, discord.Message, discord.TextChannel, discord.ThreadChannel,
    discord.DMChannel, discord.NewsChannel, discord.StageChannel, discord.BaseGuildTextChannel].filter(Boolean);
  const methods = ['reply', 'editReply', 'followUp', 'send'];
  for (const Klass of classes) {
    for (const method of methods) {
      const original = Klass.prototype?.[method];
      if (typeof original !== 'function' || original.__verdoEmojiPatched) continue;
      const wrapped = function(payload, ...rest) {
        if (method === 'reply' || method === 'editReply' || method === 'followUp' || method === 'send') {
          payload = transformPayload(payload);
        }
        return original.call(this, payload, ...rest);
      };
      wrapped.__verdoEmojiPatched = true;
      Klass.prototype[method] = wrapped;
    }
  }
}

function discordSafeEmojiName(name) {
  // Discord Application Emoji names must be 2–32 characters.
  // Keep the internal VERDO key stable while using a valid Discord name.
  if (typeof name !== 'string') return 'verdo_emoji';
  const safe = name.replace(/[^a-zA-Z0-9_]/g, '_');
  return safe.length >= 2 ? safe.slice(0, 32) : `v_${safe || 'emoji'}`.slice(0, 32);
}

function isVerdoApplicationEmoji(emoji) {
  return Boolean(emoji?.name);
}

function isVerdoSupportEmoji(emoji) {
  const name = String(emoji?.name || '');
  return name.startsWith('verdo_') || Object.prototype.hasOwnProperty.call(EMOJI_FILES, name);
}

function isVerdoSupportSticker(sticker) {
  return String(sticker?.name || '').startsWith('verdo_');
}

async function syncApplicationEmojis(client) {
  if (!client.application) return { created: 0, existing: 0, deleted: 0, failed: 0, reason: 'application unavailable' };
  try { await client.application.fetch(); } catch (err) {
    console.error(`⚠️ VERDO application fetch failed: ${formatDiscordError(err)}`);
  }
  if (!client.application.emojis) return { created: 0, existing: 0, deleted: 0, failed: 0, reason: 'application emoji manager unavailable' };

  // NON-DESTRUCTIVE SYNC: never delete/recreate application emojis on startup.
  // Existing custom emojis (including unrelated/user-created ones) stay untouched.
  const existing = await client.application.emojis.fetch().catch(() => client.application.emojis.cache);
  applicationEmojiCache = new Map();
  const byName = new Map();
  for (const emoji of existing.values()) {
    if (emoji?.name) byName.set(emoji.name, emoji);
  }

  let created = 0, existingCount = 0, failed = 0;
  const seenApplicationFiles = new Set();
  for (const [name, file] of Object.entries(ALL_EMOJI_FILES)) {
    const full = path.join(EMOJI_DIR, file);
    if (!fs.existsSync(full)) continue;

    // Upload each physical asset once. Multiple logical aliases can point to
    // the same source image, so they should reuse the same Discord emoji ID
    // instead of creating duplicate copies and wasting emoji slots.
    if (seenApplicationFiles.has(file)) {
      const canonicalName = Object.keys(ALL_EMOJI_FILES).find(k => ALL_EMOJI_FILES[k] === file);
      const canonical = applicationEmojiCache.get(canonicalName);
      if (canonical) applicationEmojiCache.set(name, canonical);
      continue;
    }
    seenApplicationFiles.add(file);

    const discordName = discordSafeEmojiName(name);
    const already = byName.get(discordName);
    if (already) {
      applicationEmojiCache.set(name, already);
      for (const [alias, aliasFile] of Object.entries(ALL_EMOJI_FILES)) {
        if (aliasFile === file) applicationEmojiCache.set(alias, already);
      }
      existingCount++;
      continue;
    }
    try {
      const buffer = fs.readFileSync(full);
      const emoji = await client.application.emojis.create({
        attachment: buffer,
        name: discordName,
        reason: 'VERDO startup: add missing branded emoji only (non-destructive sync)'
      });
      applicationEmojiCache.set(name, emoji);
      for (const [alias, aliasFile] of Object.entries(ALL_EMOJI_FILES)) {
        if (aliasFile === file) applicationEmojiCache.set(alias, emoji);
      }
      byName.set(discordName, emoji);
      created++;
    } catch (err) {
      failed++;
      console.error(`⚠️ VERDO application emoji ${name} failed: ${formatDiscordError(err)}`);
    }
  }
  return { created, existing: existingCount, deleted: 0, failed };
}

async function syncSupportGuildAssets(client) {
  let guildId = process.env.VERDO_SUPPORT_GUILD_ID || process.env.SUPPORT_GUILD_ID;
  let guild = guildId ? (client.guilds.cache.get(guildId) || await client.guilds.fetch(guildId).catch(() => null)) : null;
  if (!guild) {
    const inviteCode = process.env.VERDO_SUPPORT_INVITE || 'm8c2mUEMj';
    const invite = await client.fetchInvite(inviteCode).catch(() => null);
    guildId = invite?.guild?.id;
    guild = guildId ? (client.guilds.cache.get(guildId) || await client.guilds.fetch(guildId).catch(() => null)) : null;
  }
  if (!guild) return { skipped: true, reason: 'support guild not found' };

  const me = guild.members.me || await guild.members.fetch(client.user.id).catch(() => null);
  if (!me) return { skipped: true, reason: 'bot is not a member of the support guild' };

  const canCreateExpressions = me.permissions.has(PermissionFlagsBits.CreateGuildExpressions);
  const canManageExpressions = me.permissions.has(PermissionFlagsBits.ManageGuildExpressions);
  if (!canCreateExpressions) {
    return {
      skipped: true,
      reason: `support guild permission missing: Create Expressions=false, Manage Expressions=${canManageExpressions}. Give the bot Manage Expressions (or Create Expressions + Manage Expressions).`
    };
  }

  // STRICT NON-DESTRUCTIVE SYNC: never delete, replace, or recreate an existing
  // custom emoji. If the same target name already exists, it is always reused
  // and the upload is skipped, even if its image differs. New uploads use the
  // exact asset file from assets/emojis (same name, pixels, transparency, and quality).
  const existingEmoji = await guild.emojis.fetch().catch(() => guild.emojis.cache);
  supportEmojiCache = new Map();
  const existingEmojiByName = new Map();
  for (const emoji of existingEmoji.values()) {
    if (emoji?.name) existingEmojiByName.set(emoji.name, emoji);
  }

  let emojisCreated = 0, emojisExisting = 0, emojiFailed = 0;
  const seenSupportFiles = new Set();
  const uniqueEmojiEntries = Object.entries(ALL_EMOJI_FILES).filter(([name, file]) => {
    if (!fs.existsSync(path.join(EMOJI_DIR, file)) || seenSupportFiles.has(file)) return false;
    seenSupportFiles.add(file);
    return true;
  });
  const emojiLimit = SUPPORT_EMOJI_LIMITS[Number(guild.premiumTier)] ?? 50;
  const missingEmojiEntries = [];
  for (const [name, file] of uniqueEmojiEntries) {
    const discordName = `verdo_${discordSafeEmojiName(name)}`.slice(0, 32);
    const already = existingEmojiByName.get(discordName);
    if (already) {
      supportEmojiCache.set(name, already);
      for (const [alias, aliasFile] of Object.entries(ALL_EMOJI_FILES)) {
        if (aliasFile === file) supportEmojiCache.set(alias, already);
      }
      emojisExisting++;
    } else {
      missingEmojiEntries.push([name, file, discordName]);
    }
  }
  const availableEmojiSlots = Math.max(0, emojiLimit - existingEmoji.size);
  if (availableEmojiSlots < missingEmojiEntries.length) {
    console.warn(`⚠️ Support server emoji capacity: ${availableEmojiSlots}/${missingEmojiEntries.length} missing VERDO emojis can be added (limit ${emojiLimit}, existing ${existingEmoji.size}).`);
  }
  for (const [name, file, discordName] of missingEmojiEntries.slice(0, availableEmojiSlots)) {
    const full = path.join(EMOJI_DIR, file);
    try {
      const buffer = fs.readFileSync(full);
      const emoji = await guild.emojis.create({
        attachment: buffer,
        name: discordName,
        reason: 'VERDO startup: add missing branded emoji only (non-destructive sync)'
      });
      supportEmojiCache.set(name, emoji);
      for (const [alias, aliasFile] of Object.entries(ALL_EMOJI_FILES)) {
        if (aliasFile === file) supportEmojiCache.set(alias, emoji);
      }
      emojisCreated++;
    } catch (err) {
      emojiFailed++;
      console.error(`⚠️ Support emoji ${name} failed: ${formatDiscordError(err)}`);
    }
  }
  emojiFailed += Math.max(0, missingEmojiEntries.length - Math.min(availableEmojiSlots, missingEmojiEntries.length));

  const existingStickers = await guild.stickers.fetch().catch(() => guild.stickers.cache);
  // STRICT NON-DESTRUCTIVE SYNC: never delete, replace, or recreate an existing
  // sticker. Same target name => reuse and skip upload. New stickers use the exact
  // asset file from assets/stickers.
  const existingStickerByName = new Map();
  for (const sticker of existingStickers.values()) {
    if (sticker?.name) existingStickerByName.set(sticker.name, sticker);
  }
  supportStickerCache = new Map();

  let stickersCreated = 0, stickersExisting = 0, stickerFailed = 0;
  const stickerLimit = SUPPORT_STICKER_LIMITS[Number(guild.premiumTier)] ?? 5;
  const stickerEntries = Object.entries(STICKER_FILES);
  // VERDO sticker sources are kept as 320x320 transparent PNGs. We upload the
  // exact source bytes so Discord receives the same pixels/alpha/compression
  // quality as the bundled asset; no resize, JPEG conversion, or re-encode is done.
  console.log(`🖼️ VERDO sticker sources ready: ${stickerEntries.length} PNG assets (exact-byte upload)`);
  const missingStickerEntries = [];
  for (const [name, file] of stickerEntries) {
    const stickerName = `verdo_${discordSafeEmojiName(name)}`.slice(0, 30);
    const already = existingStickerByName.get(stickerName);
    if (already) {
      supportStickerCache.set(name, already);
      stickersExisting++;
    } else {
      missingStickerEntries.push([name, file, stickerName]);
    }
  }
  const availableStickerSlots = Math.max(0, stickerLimit - existingStickers.size);
  if (availableStickerSlots < missingStickerEntries.length) {
    console.warn(`⚠️ Support server sticker capacity: ${availableStickerSlots}/${missingStickerEntries.length} missing VERDO stickers can be added (limit ${stickerLimit}, existing ${existingStickers.size}).`);
  }
  for (const [name, file, stickerName] of missingStickerEntries.slice(0, availableStickerSlots)) {
    const full = path.join(STICKER_DIR, file);
    try {
      const buffer = fs.readFileSync(full);
      const sticker = await guild.stickers.create({
        // Send the original PNG bytes directly: no re-encoding or quality loss.
        file: { attachment: buffer, name: path.basename(full) },
        name: stickerName,
        description: (STICKER_META[name]?.description || `Official VERDO sticker — ${name}`).slice(0, 100),
        tags: STICKER_META[name]?.tags || 'robot',
        reason: 'VERDO startup: add missing branded sticker only (non-destructive sync)'
      });
      supportStickerCache.set(name, sticker);
      stickersCreated++;
    } catch (err) {
      stickerFailed++;
      console.error(`⚠️ Support sticker ${name} failed: ${formatDiscordError(err)}`);
    }
  }
  stickerFailed += Math.max(0, missingStickerEntries.length - Math.min(availableStickerSlots, missingStickerEntries.length));

  return {
    skipped: false,
    guild: guild.name,
    emojisCreated,
    emojisExisting,
    emojiFailed,
    emojisDeleted: 0,
    stickersCreated,
    stickersExisting,
    stickerFailed,
    stickersDeleted: 0
  };
}

async function syncVerdoAssets(client) {
  const app = await syncApplicationEmojis(client);
  const support = await syncSupportGuildAssets(client);
  console.log(`🎨 VERDO assets synced | App emojis: existing ${app.existing || 0}, added +${app.created || 0}, deleted 0, failed ${app.failed || 0}`);
  if (!support.skipped) {
    console.log(`🧩 Support assets [${support.guild}]: emojis deleted ${support.emojisDeleted || 0}, created +${support.emojisCreated}, failed ${support.emojiFailed || 0}; stickers deleted ${support.stickersDeleted || 0}, created +${support.stickersCreated}, failed ${support.stickerFailed || 0}`);
  } else if (support.reason !== 'support guild not found') {
    console.warn(`⚠️ Support assets skipped: ${support.reason}`);
  }
  return { app, support };
}

module.exports = {
  EMOJI_FILES,
  ALL_EMOJI_FILES,
  STICKER_FILES,
  UNICODE_TO_NAME,
  getVerdoEmoji,
  resolveCustomEmoji,
  replaceVerdoEmojiText,
  transformPayload,
  patchSendMethods,
  syncApplicationEmojis,
  syncSupportGuildAssets,
  syncVerdoAssets
};
