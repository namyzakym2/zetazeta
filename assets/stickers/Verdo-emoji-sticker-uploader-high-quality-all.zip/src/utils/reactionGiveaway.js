'use strict';

/**
 * Static reaction giveaway.
 *
 * IMPORTANT:
 * - The giveaway message/embed is sent ONCE.
 * - The original message is NEVER edited after send().
 * - Entries are collected only through the 🎉 reaction.
 * - When the giveaway ends, a NEW result message is sent.
 *
 * This keeps custom emojis inside the original embed from being lost when the
 * giveaway state changes.
 */
async function startReactionGiveaway(channel, {
  prize,
  durationMs,
  winners = 1,
  embed = {},
  reaction = '🎉',
  resultPrefix = '🎉 Giveaway ended!',
  excludeBots = true
} = {}) {
  if (!channel?.send) throw new TypeError('channel.send is required');
  if (!prize) throw new Error('prize is required');
  if (!Number.isFinite(durationMs) || durationMs <= 0) {
    throw new Error('durationMs must be > 0');
  }
  if (!Number.isInteger(winners) || winners < 1) {
    throw new Error('winners must be >= 1');
  }

  // SEND ONLY — never message.edit(), interaction.editReply(), or embed updates.
  const giveawayMessage = await channel.send({
    embeds: [{
      title: embed.title || '🎉 Giveaway',
      description: embed.description || `Prize: **${prize}**\n\nReact with ${reaction} to enter.`,
      ...embed
    }]
  });

  // Reaction is the only giveaway interaction.
  await giveawayMessage.react(reaction);

  await new Promise(resolve => setTimeout(resolve, durationMs));

  const reactionObject = giveawayMessage.reactions.cache.get(reaction);
  const users = reactionObject
    ? await reactionObject.users.fetch()
    : new Map();

  const entries = [...users.values()].filter(user => !excludeBots || !user.bot);

  // Fisher-Yates shuffle.
  for (let i = entries.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [entries[i], entries[j]] = [entries[j], entries[i]];
  }

  const selected = entries.slice(0, Math.min(winners, entries.length));
  const mentions = selected.map(user => `<@${user.id}>`);
  const result = selected.length
    ? `${resultPrefix}\n**${prize}**\nWinner${selected.length > 1 ? 's' : ''}: ${mentions.join(', ')}`
    : `${resultPrefix}\nNo valid entries were received for **${prize}**.`;

  // NEW MESSAGE ONLY — the original embed is never touched.
  await channel.send(result);

  return {
    message: giveawayMessage,
    winners: selected,
    users: entries
  };
}

module.exports = { startReactionGiveaway };
