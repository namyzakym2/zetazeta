'use strict';

// Standalone VERDO asset uploader.
// Required environment variables:
//   DISCORD_TOKEN=your_bot_token
//   VERDO_SUPPORT_GUILD_ID=your_support_server_id
// Optional:
//   VERDO_BOT_GUILD_ID=your_bot_server_id
//
// The uploader is fully non-destructive: it only adds missing VERDO assets.
// It never deletes or replaces existing custom emojis/stickers.

const { Client, GatewayIntentBits } = require('discord.js');
const { syncVerdoAssets, syncSupportGuildAssets } = require('../src/utils/verdoEmojis');

if (!process.env.DISCORD_TOKEN) {
  console.error('Missing DISCORD_TOKEN in environment.');
  process.exit(1);
}

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

async function syncNamedGuild(guildId, label) {
  if (!guildId) return null;
  const old = process.env.VERDO_SUPPORT_GUILD_ID;
  process.env.VERDO_SUPPORT_GUILD_ID = guildId;
  try {
    const result = await syncSupportGuildAssets(client);
    console.log(`\n=== ${label} ===`);
    console.log(JSON.stringify(result, null, 2));
    return result;
  } finally {
    if (old == null) delete process.env.VERDO_SUPPORT_GUILD_ID;
    else process.env.VERDO_SUPPORT_GUILD_ID = old;
  }
}

client.once('ready', async () => {
  try {
    console.log(`Logged in as ${client.user.tag}`);
    const app = await syncVerdoAssets(client);
    console.log('\n=== Application ===');
    console.log(JSON.stringify(app.app, null, 2));

    // syncVerdoAssets already handles VERDO_SUPPORT_GUILD_ID. If a separate
    // bot server is supplied, sync that server too.
    if (process.env.VERDO_BOT_GUILD_ID &&
        process.env.VERDO_BOT_GUILD_ID !== process.env.VERDO_SUPPORT_GUILD_ID) {
      await syncNamedGuild(process.env.VERDO_BOT_GUILD_ID, 'Bot server');
    }

    console.log('\nVERDO asset upload finished.');
  } catch (err) {
    console.error('VERDO upload failed:', err?.stack || err);
    process.exitCode = 1;
  } finally {
    client.destroy();
  }
});

client.login(process.env.DISCORD_TOKEN);
