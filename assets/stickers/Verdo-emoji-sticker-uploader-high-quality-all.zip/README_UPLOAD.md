# VERDO Discord asset uploader

## 1) Non-destructive custom emoji/sticker sync

The uploader now **never deletes or recreates existing custom emojis/stickers** when the bot restarts or updates.

- Existing custom emojis in the bot/application are preserved.
- Existing custom emojis in the support/bot servers are preserved.
- Existing VERDO assets are reused by name.
- Only missing VERDO assets are added.
- Unrelated server emojis/stickers are never touched.
- A startup/update therefore will not make your existing custom emojis disappear.

Run:

```bash
DISCORD_TOKEN="YOUR_BOT_TOKEN" \
VERDO_SUPPORT_GUILD_ID="SUPPORT_SERVER_ID" \
VERDO_BOT_GUILD_ID="BOT_SERVER_ID" \
node scripts/sync-verdo-assets.js
```

The bot needs **Create Expressions** to add assets. It does not need deletion permissions for the new non-destructive sync behavior.

## 2) Giveaway using reactions — no embed updates

`src/utils/reactionGiveaway.js` provides a static giveaway flow:

```js
const { startReactionGiveaway } = require('./src/utils/reactionGiveaway');

await startReactionGiveaway(channel, {
  prize: '1000 Coins',
  durationMs: 60 * 60 * 1000,
  winners: 1,
  embed: {
    title: '🎉 VERDO Giveaway',
    description: 'React with 🎉 to enter. The message will not be edited.'
  }
});
```

The giveaway message is sent once, the bot adds `🎉`, and the original embed is **never edited**. When the timer ends, the bot posts a separate result message with the winners.

Keep the bot token in an environment variable or secret manager; do not put it in the ZIP/source code.

## 3) Important: giveaway embeds are static

The giveaway helper **does not edit the giveaway embed at any point**. The flow is:

1. Send the embed once.
2. Add 🎉 reaction.
3. Wait for the duration.
4. Read the reaction users.
5. Send a separate winner/result message.

So the original embed — including VERDO custom emojis — stays untouched.


## Existing emoji/sticker protection
The uploader is strictly non-destructive: if an emoji or sticker with the target name already exists, it is reused and NOT deleted, replaced, or uploaded again. Only missing names are uploaded, using the exact bundled asset file so newly uploaded assets keep the intended name, shape/transparency, pixels, and quality.

## 4) All emoji assets + maximum sticker fidelity

- The uploader now scans `assets/emojis/` in addition to the named VERDO map, so every PNG/APNG/WebP asset in that folder is eligible for upload.
- Existing emojis are still reused by name and skipped; nothing is deleted or replaced.
- Sticker uploads send the original bundled PNG bytes directly (320×320 transparent PNGs) with no resize, JPEG conversion, or re-encoding by the bot.
- Discord's sticker-slot limit still applies (for example, a level-0 server has 5 sticker slots). The bot uploads as many missing stickers as the server has free slots and reports the remainder instead of deleting anything.
